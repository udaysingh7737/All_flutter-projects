package com.example.flutter_dilog1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
